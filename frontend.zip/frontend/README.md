# BACKEND

1. logics
   Trending
   Popular
   Binge
