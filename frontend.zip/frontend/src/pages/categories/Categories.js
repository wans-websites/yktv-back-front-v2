import React from "react";
import "./Categories.css";

export default function Categories() {
  return <section className="categories"></section>;
}
