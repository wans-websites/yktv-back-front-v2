import React from "react";
import "./Comment.css";

export default function Comment() {
  return <div>Comment</div>;
}
